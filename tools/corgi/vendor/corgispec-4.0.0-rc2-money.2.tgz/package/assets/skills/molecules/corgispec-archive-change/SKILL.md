---
name: corgispec-archive-change
description: Execute the strong, provider-neutral Archive transaction for an RFC-first Run Contract v3 delivery, materialize evidence, close knowledge and delivery state, reconcile the single Issue, and remove the worktree only after success.
hooks:
  PreToolUse:
    - matcher: "Edit|Write"
      hooks:
        - type: command
          command: "corgispec hook pre-write"
---

# Archive an RFC-first Delivery

**Context Gate**: If session context already contains ALL of: `isolation.mode`, active changes with worktree paths, current branch, reuse it; otherwise read configuration and discover worktrees.

Archive only from `ready_for_archive`. The CLI owns the durable archive intent, evidence materialization, OpenSpec move, RFC delivery CAS, tracker outbox, and final Run Contract transitions. Never construct archive paths or call provider CLIs directly.

## Strong Gate

Require:

- clean final HEAD and unchanged RFC/source/traceability/planning bindings;
- every Task Group commit, local evidence, and tracker checkpoint;
- canonical Verify PASS with full automated AC coverage;
- explicit Human Review approval;
- Human QA PASS or a valid human-confirmed no-runtime skip;
- deterministic readiness including `ARCHIVE_DELTA_COMPATIBLE`, so every `MODIFIED` requirement preserves current
  canonical scenario identities before Archive intent is created;
- exactly one Slice binding, Change, archive destination, and single Issue/provider-none binding.

Any blocker stops before mutation.

## Transaction

1. From the Human QA JSON token, run `corgispec archive "<change>" --begin --run-id "<runId>" --session "<sessionId>" --state-revision "<revision>" --nonce "<nonce>" --json`.
2. Copy the newly returned four-field token unchanged into `corgispec archive "<change>" --local --run-id "<runId>" --session "<sessionId>" --state-revision "<revision>" --nonce "<nonce>" --json`. Retry that exact operation/token after an unknown outcome.
3. Before tracker closeout, inspect the project-local integration adapter and policy. When the project requires the
   archive closeout commit to pass a PR/MR merge gate, synchronize that exact commit through the guarded adapter while
   the Run remains `archiving`; stop when ready/merge authority is unavailable. After the provider confirms that exact
   commit merged, use the guarded finalizer to run tracker confirmation and Archive finish. Never call
   `--confirm-tracker` or `--finish` directly to bypass a required integration gate.
4. When no project integration gate exists, use the next token with `--confirm-tracker` for GitHub/GitLab, then the
   latest token with `--finish`; provider `none` proceeds directly to `--finish`. Each invocation performs exactly one
   resumable phase; never reuse a superseded token.
5. Require canonical evidence materialized into the archived Change, including manifest, per-group evidence, whole-change Verify, Human Review, Human QA, and run binding.
6. Require the actual OpenSpec archived root returned by the CLI; never guess or overwrite it.
7. `corgispec archive --local` is the sole write transaction for the immutable `wiki/deliveries/<RFC-ID>-<Slice-ID>.md`, managed hot/architecture/pattern regions, MEMORY/pitfall provenance, and the archive bridge checkpoint. Use **corgispec-memory-extract** only for read-only preparation or verification; never use it to create, promote, or repair those files.
8. Require RFC `delivery.yaml` archive evidence and local archive closeout commit.
9. Let the CLI outbox or guarded finalizer move the one Issue to done and close it idempotently. Never invoke
   `gh`/`glab` directly.
10. Require `--finish` to report worktree cleanup only after required integration, local closeout, and tracker closeout
    succeed. Preserve the branch by default.

If local archive succeeds but integration or tracker closeout cannot proceed, keep the intent and worktree and resume
from that boundary without repeating the local archive or rewriting history. If an older workflow prematurely finished
and removed the worktree before publishing its archive commit, use a project-provided guarded archived-sync recovery
that verifies immutable archive evidence; never replace that proof with a raw push or direct provider edit.

If `--local` returns a known deterministic failure before local closeout completes, do not retry it unchanged and do
not edit `.corgi/loop`. Use the same current token with `corgispec archive "<change>" --request-repair --reason
"<specific failure>" ... --json`. This command may remove only reproducible untracked Change evidence and the pending
archive journal, then transitions the Run to `repair_required`. Reconcile planning through **corgispec-update**, append
exactly one Repair Task Group, create the successor through `corgispec change repair`, and repeat Apply, Verify, Human
Review, Human QA, and Archive. Never request repair after local closeout succeeds.

Report archived root, evidence manifest, delivery page, promoted knowledge, archive commit, Issue result, final `archived` phase, worktree cleanup, and any retained branch.
